const express = require("express");
const Book = require("../models/Book");
const router = express.Router();

// Add a new book
router.post("/add", async (req, res) => {
    const { title, author, genre, totalCopies, availableCopies } = req.body;
    try {
        const newBook = new Book({ title, author, genre, totalCopies, availableCopies });
        await newBook.save();
        res.status(201).json(newBook);
    } catch (err) {
        res.status(500).json({ message: "Error adding book", error: err.message });
    }
});

// Delete a book by ID
router.delete("/:id", async (req, res) => {
    try {
        await Book.findByIdAndDelete(req.params.id);
        res.status(200).json({ message: "Book deleted" });
    } catch (err) {
        res.status(500).json({ message: "Error deleting book", error: err.message });
    }
});

// Search books by genre
router.get("/search", async (req, res) => {
    const { genre } = req.query;
    try {
        const books = await Book.find({ genre });
        res.status(200).json(books);
    } catch (err) {
        res.status(500).json({ message: "Error searching books", error: err.message });
    }
});

module.exports = router;
