const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const usersRoute = require("./routes/users");
const booksRoute = require("./routes/books");

const app = express();
const port = 3000;

mongoose.connect("mongodb://localhost:27017/library", { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log("Connected to MongoDB"))
    .catch(err => console.log("MongoDB connection error: " + err));

app.use(bodyParser.json());

// Serve the login page
app.get("/", (req, res) => {
    res.sendFile(__dirname + "/views/login.html");
});

// Serve the admin dashboard (admin page after login)
app.get("/admin", (req, res) => {
    res.sendFile(__dirname + "/views/dashboard.html");
});

app.use("/api/users", usersRoute);
app.use("/api/books", booksRoute);

app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
