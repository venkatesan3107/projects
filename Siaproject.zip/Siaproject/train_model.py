import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import joblib

# Create a mock dataset with hexadecimal string features
data = pd.DataFrame({
    'feature1': ["A4 23 69 9F", "5A 68 2C 35", "6D 6F 4A B3", "4F 9E 3A 8C", "AF 5C 69 8A", "3C 1A 56 8F",
                 "B3 5E 79 40", "12 34 56 78", "9A BC DE F0", "AA BB CC DD", "FF EE DD CC", "11 22 33 44",
                 "55 66 77 88", "99 AA BB CC", "DD EE FF 00", "11 22 33 44", "55 66 77 88", "99 AA BB CC",
                 "DD EE FF 00", "01 23 45 67"],
    'feature2': ["5A 68 2C 35", "6D 6F 4A B3", "A4 23 69 9F", "AF 5C 69 8A", "3C 1A 56 8F", "4F 9E 3A 8C",
                 "9A BC DE F0", "B3 5E 79 40", "12 34 56 78", "DD EE FF 00", "AA BB CC DD", "FF EE DD CC",
                 "11 22 33 44", "55 66 77 88", "99 AA BB CC", "DD EE FF 00", "01 23 45 67", "11 22 33 44",
                 "55 66 77 88", "99 AA BB CC"],
    'feature3': ["6D 6F 4A B3", "A4 23 69 9F", "5A 68 2C 35", "3C 1A 56 8F", "4F 9E 3A 8C", "AF 5C 69 8A",
                 "12 34 56 78", "9A BC DE F0", "B3 5E 79 40", "11 22 33 44", "55 66 77 88", "99 AA BB CC",
                 "DD EE FF 00", "AA BB CC DD", "FF EE DD CC", "55 66 77 88", "99 AA BB CC", "DD EE FF 00",
                 "01 23 45 67", "11 22 33 44"],
    'label': ['AES', 'DES', 'RSA', 'SHA-1', 'SHA-2', 'SHA-3', 'MD5', 'AES', 'DES', 'RSA', 'SHA-1', 'SHA-2', 
              'SHA-3', 'MD5', 'AES', 'DES', 'RSA', 'SHA-1', 'SHA-2', 'SHA-3']
})

# Preprocessing: Convert hexadecimal strings to numerical values
# Convert hex string to integer
def hex_to_int(hex_str):
    return int(hex_str.replace(" ", ""), 16)

# Apply the conversion to the dataset
for col in ['feature1', 'feature2', 'feature3']:
    data[col] = data[col].apply(hex_to_int)

X = data.drop('label', axis=1)
y = data['label']

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train the model
model = RandomForestClassifier()
model.fit(X_train, y_train)

# Save the model
joblib.dump(model, 'models/model.pkl')

print("Model trained and saved successfully.")
