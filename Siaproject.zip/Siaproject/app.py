from flask import Flask, render_template, request, redirect, url_for, flash
import os
import joblib
import pandas as pd
from werkzeug.utils import secure_filename

# Initialize Flask app
app = Flask(__name__)
app.secret_key = 'your_secret_key'
app.config['UPLOAD_FOLDER'] = 'uploads/'

# Load the pre-trained AI/ML model
model = joblib.load('models/model.pkl')

# Ensure upload folder exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Route to the home page
@app.route('/')
def index():
    return render_template('index.html')

# Route to the upload page
@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        file = request.files['file']
        if file:
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)

            # Preprocess the uploaded data
            data = preprocess_data(filepath)

            # Make predictions
            prediction = model.predict(data)
            algorithm_name = get_algorithm_name(prediction)

            return redirect(url_for('result', algorithm=algorithm_name))
    return render_template('upload.html')

# Route to the result page
@app.route('/result')
def result():
    algorithm = request.args.get('algorithm')
    return render_template('result.html', algorithm=algorithm)

def preprocess_data(filepath):
    # Load the dataset
    data = pd.read_csv(filepath)

    # Example preprocessing (customize based on your model)
    # data = some_preprocessing_function(data)

    return data

def get_algorithm_name(prediction):
    # Translate prediction to algorithm name
    # Example (customize based on your model)
    algorithm_map = {
        0: 'AES',
        1: 'DES',
        2: 'RSA',
        # Add more mappings as needed
    }
    return algorithm_map.get(prediction[0], "Unknown")

if __name__ == '__main__':
    app.run(debug=True)
