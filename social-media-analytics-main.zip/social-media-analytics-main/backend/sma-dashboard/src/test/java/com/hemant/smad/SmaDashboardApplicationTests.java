package com.hemant.smad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmaDashboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
