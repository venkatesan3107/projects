import torch
from torch.utils.data import DataLoader
from dataset import MelasmaDataset
from unet import UNet
import torch.nn as nn
import torch.optim as optim

# -----------------------------
# CONFIG
# -----------------------------
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
EPOCHS = 25
BATCH_SIZE = 4
LR = 1e-4

# -----------------------------
# DATASETS
# -----------------------------
train_dataset = MelasmaDataset(
    images_dir="train/images",
    masks_dir="train/masks"
)

val_dataset = MelasmaDataset(
    images_dir="valid/images",
    masks_dir="valid/masks"
)

train_loader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=BATCH_SIZE)

# -----------------------------
# MODEL
# -----------------------------
model = UNet().to(DEVICE)
criterion = nn.BCELoss()
optimizer = optim.Adam(model.parameters(), lr=LR)

# -----------------------------
# TRAINING LOOP
# -----------------------------
for epoch in range(EPOCHS):
    model.train()
    train_loss = 0

    for imgs, masks in train_loader:
        imgs, masks = imgs.to(DEVICE), masks.to(DEVICE)

        preds = model(imgs)
        loss = criterion(preds, masks)

        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        train_loss += loss.item()

    train_loss /= len(train_loader)

    print(f"Epoch [{epoch+1}/{EPOCHS}] - Train Loss: {train_loss:.4f}")

# -----------------------------
# SAVE MODEL
# -----------------------------
torch.save(model.state_dict(), "melasma_unet.pth")
print("✅ Model saved as melasma_unet.pth")
