# pigmentation > 2026-01-05 12:18pm
https://universe.roboflow.com/venkat-ukg3b/pigmentation-d9lau-turlu

Provided by a Roboflow user
License: CC BY 4.0

This project identifies the presence of uneven skin tone - hyper/hypo pigmentation 