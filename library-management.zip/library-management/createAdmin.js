const mongoose = require('mongoose');
const Admin = require('./models/Admin');

const mongoURI = 'mongodb://127.0.0.1:27017/library'; // Change if needed

mongoose.connect(mongoURI)
    .then(async () => {
        console.log('MongoDB connected successfully');

        // Create a new admin user
        const username = 'admin';
        const password = 'admin123';

        const newAdmin = new Admin({ username, password });
        await newAdmin.save();
        console.log('Admin user created successfully');

        mongoose.connection.close();
    })
    .catch(err => {
        console.error('MongoDB connection error:', err);
        mongoose.connection.close();
    });
