const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const bcrypt = require('bcryptjs'); // Import bcrypt for password comparison
const jwt = require('jsonwebtoken'); // Import jsonwebtoken for token generation

const app = express();

// Middleware
app.use(cors());  // Enable CORS for API access
app.use(bodyParser.urlencoded({ extended: true })); // Parse form data
app.use(bodyParser.json());  // Parse JSON requests

// Serve static files from the public directory
app.use(express.static(path.join(__dirname, 'public')));

// Connect to MongoDB
const mongoURI = 'mongodb://127.0.0.1:27017/library'; // Change if needed
mongoose.connect(mongoURI)
    .then(() => console.log('MongoDB connected successfully'))
    .catch(err => console.error('MongoDB connection error:', err));

// Book Schema
const bookSchema = new mongoose.Schema({
    title: String,
    author: String,
    genre: String,
    totalCopies: Number,
    availableCopies: Number,
    isbn: String
});

const Book = mongoose.model('Book', bookSchema);

// Admin Schema
const adminSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true },
    password: { type: String, required: true }
});

const Admin = mongoose.model('Admin', adminSchema);

// 🟢 API Routes

// ➤ Root Route
app.get('/', (req, res) => {
    console.log("Received request for root route");
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

// ➤ Dashboard Route
app.get('/dashboard.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'dashboard.html'));
});

app.get('/add-book', (req, res) => {
    console.log("Serving add-book.html");
    res.sendFile(path.join(__dirname, 'views', 'add-book.html')); // Serve the correct file
});

// ➤ Admin Login
app.post('/api/admin/login', async (req, res) => {
    const { username, password } = req.body;

    try {
        const admin = await Admin.findOne({ username });
        if (!admin) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }

        const isMatch = await bcrypt.compare(password, admin.password);
        if (!isMatch) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }

        // Generate a token (you can customize the payload and expiration)
        const token = jwt.sign({ id: admin._id }, 'your_jwt_secret', { expiresIn: '1h' });
        res.json({ token });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// ➤ Get All Books
app.get('/api/books', async (req, res) => {
    try {
        const books = await Book.find();
        res.json(books);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error fetching books' });
    }
});

// ➤ Add a New Book
app.post('/api/books/add', async (req, res) => {
    console.log("Received Data:", req.body);  // Debugging

    const { title, author, genre, totalCopies, isbn } = req.body;

    if (!title || !author || !genre || !totalCopies || !isbn) {
        return res.status(400).json({ message: "All fields are required." });
    }

    try {
        const newBook = new Book({
            title,
            author,
            genre,
            totalCopies,
            availableCopies: totalCopies, // Initially set available copies equal to total
            isbn
        });

        const savedBook = await newBook.save();
        res.status(201).json({ success: true, book: savedBook });
    } catch (error) {
        console.error("Error adding book:", error);
        res.status(500).json({ message: "Error adding book", error: error.message });
    }
});

// ➤ Delete a Book
app.delete('/api/books/:id', async (req, res) => {
    try {
        await Book.findByIdAndDelete(req.params.id);
        res.json({ message: "Book deleted successfully" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Error deleting book" });
    }
});

// ➤ Update Book Details
app.put('/api/books/:id', async (req, res) => {
    try {
        const updatedBook = await Book.findByIdAndUpdate(req.params.id, req.body, { new: true });
        res.json(updatedBook);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Error updating book" });
    }
});

// Start Server on a different port
const PORT = process.env.PORT || 3001; // Changed to 3001
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
