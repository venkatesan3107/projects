const express = require('express');
const Book = require('../models/Book');
const router = express.Router();

// Middleware to authenticate the user (admin)
function authenticateAdmin(req, res, next) {
    const token = req.headers['authorization']?.split(' ')[1];

    if (!token) return res.status(401).json({ message: 'No token, authorization denied' });

    jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
        if (err) return res.status(401).json({ message: 'Token is not valid' });
        req.adminId = decoded.adminId;
        next();
    });
}

router.post('/add', authenticateAdmin, async (req, res) => {
    const { title, author, genre, availableCopies } = req.body;

    try {
        const newBook = new Book({ title, author, genre, availableCopies });
        await newBook.save();
        res.status(201).json(newBook);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error adding book' });
    }
});

router.put('/update', authenticateAdmin, async (req, res) => {
    const { bookId, title, author, genre, totalCopies, isbn } = req.body;

    try {
        const updatedBook = await Book.findByIdAndUpdate(bookId, {
            title,
            author,
            genre,
            totalCopies,
            availableCopies: totalCopies // Update available copies as well
        }, { new: true });

        if (!updatedBook) {
            return res.status(404).json({ success: false, message: 'Book not found' });
        }

        res.json({ success: true, book: updatedBook });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, message: 'Error updating book' });
    }
});

router.delete('/:id', authenticateAdmin, async (req, res) => {
    try {
        const book = await Book.findByIdAndDelete(req.params.id);

        if (!book) {
            return res.status(404).json({ message: 'Book not found' });
        }

        res.json({ message: 'Book deleted successfully' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error deleting book' });
    }
});

router.get('/search/isbn', async (req, res) => {
    const { isbn } = req.query;
    console.log(`Received request to search for book with ISBN: ${isbn}`); // Debugging log
    try {
        const book = await Book.findOne({ isbn: isbn });
        if (!book) {
            return res.status(404).json({ message: 'Book not found' });
        }
        res.json(book);
    } catch (error) {
        console.error("Error fetching book:", error); // More detailed error logging
        res.status(500).json({ message: 'Error fetching book' });
    }
});

router.get('/search', async (req, res) => {
    const { genre, title } = req.query;

    try {
        const query = {};
        if (genre) query.genre = genre;
        if (title) query.title = { $regex: title, $options: 'i' }; // Case-insensitive search

        const books = await Book.find(query);
        res.json(books);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error fetching books' });
    }
});

router.get('/', async (req, res) => {
    try {
        const books = await Book.find();
        res.json(books);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error fetching books' });
    }
});

router.get('/add-book', (req, res) => {
    res.render('add-book'); // Render the add-book view
});

module.exports = router;
