const jwt = require('jsonwebtoken');

module.exports = (req, res, next) => {
  // Support both 'Authorization: token' and 'Authorization: Bearer token' formats
  const authHeader = req.header('Authorization');
  if (!authHeader) return res.status(401).json({ message: 'Access Denied - No token provided' });

  // Extract token from header
  const token = authHeader.startsWith('Bearer ') 
    ? authHeader.split(' ')[1] 
    : authHeader;

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your_admin_secret_key');
    if (decoded.role !== 'admin') {
      return res.status(403).json({ message: 'Forbidden: Admins only' });
    }
    req.admin = decoded;
    next();
  } catch (err) {
    console.error('Token verification error:', err);
    res.status(401).json({ 
      message: 'Invalid Token',
      error: err.message 
    });
  }
};
