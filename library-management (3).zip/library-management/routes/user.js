const express = require('express');
const User = require('../models/User');
const router = express.Router();

// Assuming a simple User model exists (you need to create it as per your requirements)
router.post('/register', async (req, res) => {
    const { username, password } = req.body;
    try {
        const newUser = new User({ username, password });
        await newUser.save();
        res.status(201).json({ message: 'User registered' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error registering user' });
    }
});

module.exports = router;
