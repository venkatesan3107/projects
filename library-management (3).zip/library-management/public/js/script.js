document.addEventListener('DOMContentLoaded', function() {
    console.log('JavaScript is working!');
});
