require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// Import models
const Book = require('./models/Book');
const Admin = require('./models/Admin');

const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// Connect to MongoDB with timeout and retry
const mongoURI = 'mongodb://127.0.0.1:27017/library?retryWrites=true&w=majority';
const mongooseOptions = {
  connectTimeoutMS: 10000,
  socketTimeoutMS: 30000,
  serverSelectionTimeoutMS: 5000,
  retryWrites: true,
  retryReads: true
};

async function connectDB() {
  try {
    await mongoose.connect(mongoURI, mongooseOptions);
    console.log('MongoDB connected successfully');
    
    // Verify admin account exists
    const admin = await Admin.findOne({username: 'admin'});
    if (!admin) {
      const hashedPassword = await bcrypt.hash('adminpassword', 10);
      await Admin.create({username: 'admin', password: hashedPassword});
      console.log('Default admin account created');
    }
  } catch (err) {
    console.error('MongoDB connection error:', err);
    process.exit(1);
  }
}

connectDB();

// Import routes
const bookRoutes = require('./routes/book');

// Mount routes
app.use('/api/books', bookRoutes);

// View routes
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'login.html'));
});

app.get('/dashboard.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'dashboard.html'));
});

app.get('/add-book', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'add-book.html'));
});

app.get('/search-book', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'search-book-updated.html'));
});

app.get('/alter-book', (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'alter-book.html'));
});

// Admin Login
app.post('/api/admin/login', async (req, res) => {
    const { username, password } = req.body;

    try {
        const admin = await Admin.findOne({ username });
        if (!admin) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }

        const isMatch = await bcrypt.compare(password, admin.password);
        if (!isMatch) {
            return res.status(401).json({ message: 'Invalid credentials' });
        }

        const token = jwt.sign({ adminId: admin._id }, process.env.JWT_SECRET, { expiresIn: '1h' });
        res.json({ token });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Server error' });
    }
});

// Start Server
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
