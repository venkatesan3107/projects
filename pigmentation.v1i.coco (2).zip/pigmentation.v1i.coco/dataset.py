import os
import cv2
import torch
from torch.utils.data import Dataset
import numpy as np

class MelasmaDataset(Dataset):
    def __init__(self, images_dir, masks_dir):
        self.images_dir = images_dir
        self.masks_dir = masks_dir
        self.images = sorted(os.listdir(images_dir))

    def __len__(self):
        return len(self.images)

    def __getitem__(self, idx):
        img_name = self.images[idx]

        # Read image
        img = cv2.imread(os.path.join(self.images_dir, img_name))
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img = cv2.resize(img, (256, 256))
        img = img / 255.0
        img = torch.tensor(img, dtype=torch.float32).permute(2, 0, 1)

        # Read mask
        mask_name = img_name.rsplit(".", 1)[0] + ".png"
        mask = cv2.imread(os.path.join(self.masks_dir, mask_name), 0)
        mask = cv2.resize(mask, (256, 256))
        mask = mask / 255.0
        mask = torch.tensor(mask, dtype=torch.float32).unsqueeze(0)

        return img, mask
